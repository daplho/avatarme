# Identicon starter project

# Prerequisites:
- Java
- Maven
- Docker

## Running Project

```bash
mvn clean install && sudo docker build --tag=identicon . && sudo docker run -it -p 8080:8080 identicon
```

