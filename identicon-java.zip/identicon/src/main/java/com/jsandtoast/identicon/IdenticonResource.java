package com.jsandtoast.identicon;

import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;

import javax.imageio.ImageIO;
import javax.ws.rs.*;
import javax.ws.rs.core.Response;
import java.awt.image.RenderedImage;
import java.io.ByteArrayOutputStream;
import java.io.IOException;

/**
 * Created by jsantos on 11/23/16.
 */
@Path("/rendered_image")
public class IdenticonResource {

    private static final Log log = LogFactory.getLog(IdenticonResource.class);

    private IdenticonRenderer renderer = new IdenticonRenderer();

    private static final String PARAM_IDENTICON_SIZE = "size";
    private static final String PARAM_IDENTICON_CODE = "code";
    private static final String IDENTICON_IMAGE_FORMAT = "PNG";

    public IdenticonResource() {
        IdenticonUtil.setInetSalt("foobar");
    }

    @GET
    @Path("/")
    @Produces("image/png")
    public Response getIdenticon(@QueryParam(PARAM_IDENTICON_CODE) String requestCode,
                                 @QueryParam(PARAM_IDENTICON_SIZE) String requestSize) {
        int code = IdenticonUtil.getIdenticonCode(requestCode, null);
        int size = IdenticonUtil.getIdenticonSize(requestSize);
        ByteArrayOutputStream byteOut = new ByteArrayOutputStream();
        log.info("Rendering image with code " + requestCode + " and size " + requestSize);
        RenderedImage image = renderer.render(code, size);
        try {
            ImageIO.write(image, IDENTICON_IMAGE_FORMAT, byteOut);
        } catch (IOException e) {
            return Response.serverError().build();
        }
        return  Response.ok(byteOut.toByteArray()).build();
    }
}
